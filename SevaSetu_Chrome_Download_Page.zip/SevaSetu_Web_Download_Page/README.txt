SEVASETU DOWNLOAD PAGE

1. Upload this page to your own website/hosting.
2. Replace SEVASETU_APK_URL with the public HTTPS URL of the signed APK.
3. Replace SEVASETU_PLAY_STORE_URL with the Play Store listing URL after publication.
4. APK should be signed and built for Android. For Google Play, publish an AAB.
5. Android/Chrome may show security warnings for apps installed outside Play Store; users must only install an APK from a trusted HTTPS source.
